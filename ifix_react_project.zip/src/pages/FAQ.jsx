import React from 'react'
export default function FAQ(){
  return (
    <section className="section">
      <h2>Frequently Asked Questions</h2>
      <ul>
        <li><strong>Do you provide same-day repair?</strong> Yes, for most iPhone and iPad repairs.</li>
        <li><strong>Are the parts original?</strong> We provide OEM-grade and premium-quality parts.</li>
        <li><strong>Do you offer doorstep service?</strong> Yes, within Patna city limits.</li>
      </ul>
    </section>
  )
}
