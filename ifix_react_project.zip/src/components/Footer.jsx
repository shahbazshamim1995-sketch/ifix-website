import React from 'react'
export default function Footer(){
  return (
    <footer>
      <div style={{maxWidth:1100,margin:'0 auto',display:'flex',justifyContent:'space-between',alignItems:'center',gap:20,flexWrap:'wrap'}}>
        <div style={{textAlign:'left'}}>
          <h3 style={{margin:0}}>iFix Service Center</h3>
          <p style={{margin:'6px 0 0 0'}}>📞 9798653591</p>
          <p style={{margin:'6px 0 0 0'}}>📍 Patna, Bihar</p>
        </div>
        <div style={{textAlign:'right'}}>
          <p style={{margin:0}}>© 2025 iFix Service Center. All Rights Reserved.</p>
        </div>
      </div>
    </footer>
  )
}
