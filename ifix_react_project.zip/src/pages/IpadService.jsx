import React from 'react'
export default function IpadService(){
  return (
    <section className="section">
      <h1>iPad Service Center in Patna – iFix</h1>
      <p>iPad screen, battery, and motherboard repair with same-day service options.</p>
    </section>
  )
}
