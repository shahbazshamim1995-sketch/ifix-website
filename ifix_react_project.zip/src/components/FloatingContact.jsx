import React from 'react'
export default function FloatingContact(){
  return (
    <div style={{position:'fixed',right:18,bottom:18,zIndex:9999,display:'flex',flexDirection:'column',gap:12}}>
      <a href="tel:+919798653591" style={{display:'inline-flex',alignItems:'center',padding:'12px 14px',borderRadius:10,background:'#000',color:'#fff',textDecoration:'none'}}>📞 Call</a>
      <a href="https://wa.me/919798653591" target="_blank" rel="noreferrer" style={{display:'inline-flex',alignItems:'center',padding:'12px 14px',borderRadius:10,background:'#25D366',color:'#fff',textDecoration:'none'}}>💬 WhatsApp</a>
    </div>
  )
}
