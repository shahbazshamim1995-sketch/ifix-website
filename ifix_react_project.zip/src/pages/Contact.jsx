import React from 'react'
export default function Contact(){
  return (
    <section className="section" id="contact">
      <h1>Contact iFix</h1>
      <p>Call: +91-9798653591</p>
      <p>Address: Patna, Bihar</p>
      <a href="https://wa.me/919798653591" target="_blank" rel="noreferrer">Chat on WhatsApp</a>
    </section>
  )
}
