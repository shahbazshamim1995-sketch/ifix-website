import React from 'react'
import { Link } from 'react-router-dom'
export default function TopNav(){
  return (
    <header className="topnav">
      <div className="logo">iFix Service Center</div>
      <nav>
        <Link to="/">Home</Link>
        <Link to="/iphone-service-center-in-patna">iPhone Service</Link>
        <Link to="/macbook-service-center-in-patna">MacBook Service</Link>
        <Link to="/ipad-service-center-in-patna">iPad Service</Link>
        <Link to="/applecare-support-patna">Apple Care</Link>
        <Link to="/faq">FAQ</Link>
        <Link to="/contact">Contact</Link>
      </nav>
    </header>
  )
}
