import React from 'react'
export default function AppleCare(){
  return (
    <section className="section">
      <h1>Apple Care Support in Patna – iFix</h1>
      <p>Device diagnostics, support assistance, and extended care guidance for all Apple devices.</p>
    </section>
  )
}
