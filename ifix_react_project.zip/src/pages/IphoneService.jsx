import React from 'react'
export default function IphoneService(){
  return (
    <section className="section">
      <h1>iPhone Service Center in Patna – iFix</h1>
      <p>Premium iPhone repair, battery replacement, screen replacement, and diagnostics in Patna.</p>
    </section>
  )
}
