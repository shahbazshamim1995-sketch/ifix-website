import React from 'react'
export default function Home(){
  return (
    <>
      <section className="hero">
        <h1>Fast & Trusted Apple Repair in Patna</h1>
        <p>iPhone, MacBook, iPad repair | Genuine parts | Warranty</p>
        <button className="cta" onClick={()=>window.location.href='/contact'}>Book Appointment</button>
      </section>

      <section className="section" id="services">
        <h2 style={{textAlign:'center'}}>Our Services</h2>
        <div style={{display:'grid',gridTemplateColumns:'repeat(auto-fit,minmax(250px,1fr))',gap:20,marginTop:20}}>
          <div className="card"><h3>iPhone Repair</h3><p>Screen, battery, motherboard & more.</p></div>
          <div className="card"><h3>MacBook Repair</h3><p>Keyboard, display, SSD, liquid damage.</p></div>
          <div className="card"><h3>iPad Repair</h3><p>Screen replacement & all hardware fixes.</p></div>
          <div className="card"><h3>Apple Care Support</h3><p>Diagnostics, software & support.</p></div>
        </div>
      </section>
    </>
  )
}
