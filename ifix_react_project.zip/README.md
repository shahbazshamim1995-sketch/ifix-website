iFix React project - Minimal Vite React setup

To run locally:

1. Install dependencies:
   npm install

2. Start dev server:
   npm run start

3. Build for production:
   npm run build

Notes:
- This project is intentionally minimal. Replace placeholder images in /assets and update meta tags in public/index.html.
- Configure an actual backend for contact form (or use serverless functions).
