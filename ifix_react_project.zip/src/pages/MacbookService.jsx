import React from 'react'
export default function MacbookService(){
  return (
    <section className="section">
      <h1>MacBook Service Center in Patna – iFix</h1>
      <p>Expert MacBook repair, SSD upgrade, keyboard replacement, and motherboard services.</p>
    </section>
  )
}
