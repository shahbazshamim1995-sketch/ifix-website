<?php
// Simple mail handler (for demo). Configure before using in production.
if($_SERVER['REQUEST_METHOD']==='POST'){
  $name = strip_tags(trim($_POST['name'] ?? ''));
  $phone = strip_tags(trim($_POST['phone'] ?? ''));
  $device = strip_tags(trim($_POST['device'] ?? ''));
  $message = strip_tags(trim($_POST['message'] ?? ''));
  $to = 'youremail@example.com'; // CHANGE to your email
  $subject = "New appointment from iFix website";
  $body = "Name: $name\nPhone: $phone\nDevice: $device\nMessage:\n$message";
  $headers = "From: noreply@ifixservice.co.in\r\nReply-To: noreply@ifixservice.co.in";
  if(mail($to,$subject,$body,$headers)){
    echo 'success';
  } else {
    echo 'error';
  }
}
?>