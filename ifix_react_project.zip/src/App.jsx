import React from 'react'
import { Routes, Route } from 'react-router-dom'
import TopNav from './components/TopNav'
import FloatingContact from './components/FloatingContact'
import Footer from './components/Footer'
import Home from './pages/Home'
import IphoneService from './pages/IphoneService'
import MacbookService from './pages/MacbookService'
import IpadService from './pages/IpadService'
import AppleCare from './pages/AppleCare'
import FAQ from './pages/FAQ'
import Contact from './pages/Contact'

export default function App(){
  return (
    <>
      <TopNav />
      <main style={{minHeight:'70vh'}}>
        <Routes>
          <Route path='/' element={<Home/>} />
          <Route path='/iphone-service-center-in-patna' element={<IphoneService/>} />
          <Route path='/macbook-service-center-in-patna' element={<MacbookService/>} />
          <Route path='/ipad-service-center-in-patna' element={<IpadService/>} />
          <Route path='/applecare-support-patna' element={<AppleCare/>} />
          <Route path='/faq' element={<FAQ/>} />
          <Route path='/contact' element={<Contact/>} />
        </Routes>
      </main>
      <FloatingContact />
      <Footer />
    </>
  )
}
